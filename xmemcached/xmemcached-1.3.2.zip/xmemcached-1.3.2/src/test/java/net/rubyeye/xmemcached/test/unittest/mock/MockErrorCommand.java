package net.rubyeye.xmemcached.test.unittest.mock;

public interface MockErrorCommand {
	public boolean isDecoded();

}
