package com.paipai.api.util;

public enum ReservedName {
	CHARSET("charset"),
	FORMAT("format"),
	PUREDATA("pureData"),
	DEBUG("debug"),

	UIN("uin"),
	SPID("spid"),
	TOKEN("token"),
	SKEY("skey"),
	SIGN("sign");
	
	private String desc;
	private ReservedName(String desc) {
		this.desc = desc;
	}
	public String toString() {
		return desc;
	}
}
